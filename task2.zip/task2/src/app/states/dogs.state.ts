import { State, Action, StateContext } from '@ngxs/store';
import { Injectable } from '@angular/core';
import { DogsService } from '../services/dogs.service';
import { GetDogs, GetImages } from '../actions/dogs.actions';

export class DogStateModel {
    dogList: any;
    breedList: any;
    imageList: any;
}

@State<DogStateModel>({
    name: 'dogs',
    defaults: {
        dogList: null,
        breedList: null,
        imageList: null
    }
})

@Injectable()
export class DogState {

    constructor(private dogsService: DogsService) {}

    @Action(GetDogs)
    getDogs({setState}: StateContext<any>) {
        this.dogsService.getDogs();
        this.dogsService.dogList$.subscribe((data)=>{
            setState({
                dogList: data,
                breedList: Object.keys(data)
            });
        });

    }

    @Action(GetImages)
    getImages({getState, setState}: StateContext<any>, { payload }: any) {
        const state = getState();
        setState({...state, imageList: null }); //clear image list first
        this.dogsService.getImages(payload);
        if (this.dogsService.imageList$.observers.length === 0) { // only subscribe once
            this.dogsService.imageList$.subscribe((data) => {
                setState({
                    ...state,
                    imageList: data
                });
            });
        }
    }

}