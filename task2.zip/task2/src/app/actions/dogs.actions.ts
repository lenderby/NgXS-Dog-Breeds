
export class GetDogs {
    static readonly type = '[Dogs] Get Dogs';

    constructor() {}
}

export class GetImages {
    static readonly type = '[Dogs] Get Images';

    constructor(public payload: string) {}
}