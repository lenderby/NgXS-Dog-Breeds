import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxsModule } from '@ngxs/store';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WebComponent } from './views/web/web.component';
import { MobileComponent } from './views/mobile/mobile.component';
import { DogState } from './states/dogs.state';
import { ImagesComponent } from './views/shared/images/images.component';

@NgModule({
  declarations: [
    AppComponent,
    WebComponent,
    MobileComponent,
    ImagesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxsModule.forRoot([
      DogState
    ]),
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
