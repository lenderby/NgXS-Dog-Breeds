import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class DogsService {

  private endpoint: string = 'https://dog.ceo/api';

  public dogList$: Subject<any[]> = new Subject;
  public imageList$: Subject<any[]> = new Subject;

  constructor() { }

  public getDogs() {
    fetch(this.endpoint + '/breeds/list/all', { mode: 'cors' })
     .then(response => response.json())
     .then(data => {
      if (data) {
        this.dogList$.next(data.message);
      } else {
        console.error('There is a problem with the data');
      }
    })
     .catch(error => {
      console.error('Url not working: '+ error);

     });
  }

  public getImages(breed: string) {
    fetch(this.endpoint + '/breed/' + breed + '/images', { mode: 'cors'})
      .then(response => response.json())
      .then(data => {
        if (data) {
          this.imageList$.next(data.message);
        } else {
          console.error('There is a problem with retrieving the images');
        }
      })
      .catch(error => {
        console.error('Url not working: '+ error);

      });
  }
}
