import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WebComponent } from './views/web/web.component';
import { MobileComponent } from './views/mobile/mobile.component';

const routes: Routes = [
  { path: 'web', component: WebComponent },
  { path: 'mobile', component: MobileComponent },
  { path: '**', redirectTo: window.screen.width > 767 ? 'web': 'mobile' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
