import { Component, OnInit } from '@angular/core';
// import { DogsService } from './services/dogs.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'task2';

  constructor(
    // private recipesService: DogsService
    ) {}

  ngOnInit() {
    // this.recipesService.getDogs();
    // this.recipesService.getImages('hound');
  }

}
