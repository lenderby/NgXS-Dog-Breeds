import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { GetDogs, GetImages } from 'src/app/actions/dogs.actions';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.scss']
})
export class MobileComponent implements OnInit {

  public breedList$: any;
  public imageList$: any;
  public selectedBreed: string = '';

  constructor(
    private store: Store
  ) {
    this.breedList$ = this.store.select(state => state.dogs.breedList);
    this.imageList$ = this.store.select(state => state.dogs.imageList);
  }

  ngOnInit(): void {
    this.store.dispatch(new GetDogs());
  }

  onBreedSelect(): void {
    this.store.dispatch(new GetImages(this.selectedBreed));
  }

}
