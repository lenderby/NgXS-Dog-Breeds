import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { GetDogs, GetImages } from 'src/app/actions/dogs.actions';
import { ImagesComponent } from '../shared/images/images.component'

@Component({
  selector: 'app-web',
  templateUrl: './web.component.html',
  styleUrls: ['./web.component.scss']
})
export class WebComponent implements OnInit {

  public breedList$: any;
  public imageList$: any;
  public selectedBreed: string = '';

  constructor(
    private store: Store
  ) {
    this.breedList$ = this.store.select(state => state.dogs.breedList);
    this.imageList$ = this.store.select(state => state.dogs.imageList);
   }

  ngOnInit(): void {
    this.store.dispatch(new GetDogs());
  }

  onBreedClick(breed: string): void {
    this.selectedBreed = breed;
    this.store.dispatch(new GetImages(breed));
  }

  isBreed(breed: string) : boolean {
    return breed == this.selectedBreed;
  }
}
