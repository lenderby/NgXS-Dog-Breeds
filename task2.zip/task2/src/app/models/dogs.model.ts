export interface Breeds {
    breeds: SubBreed[]
}

export interface SubBreed {
    
}